MDS3FL: MDS Federated Learning package
